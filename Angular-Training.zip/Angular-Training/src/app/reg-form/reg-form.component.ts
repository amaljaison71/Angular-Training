import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { Visitor } from '../visitor';
import { RegServiceService } from '../reg-service.service';

@Component({
  selector: 'app-reg-form',
  templateUrl: './reg-form.component.html',
  styleUrls: ['./reg-form.component.sass']
})
export class RegFormComponent implements OnInit {

  regForm = this.fb.group({
    name: ['',[Validators.required, this.nameValidator]],
    address: ['',Validators.required],
    phone: ['',[Validators.required, Validators.minLength(9), Validators.maxLength(10)]],
    temperature: ['',[Validators.required,this.temperatureValidator]]
  });

  constructor(private fb: FormBuilder, private regService: RegServiceService) { }

  ngOnInit() {
  }

  saveData() {
    let visitor: Visitor = this.regForm.value;
    visitor.visitor_id = null;
    visitor.organization_id = 1;
    console.log(visitor);
    this.saveLog(visitor);
  }

  saveLog(visitor: Visitor) {
    this.regService.saveLog(visitor).subscribe( (res) => {
      console.log("Saved!");
      console.log(res);
    } )
  }

  temperatureValidator (control: AbstractControl):{[key: string]: boolean} | null {

    if( control.value !==null && (isNaN(control.value) || control.value <80  || control.value> 100)){
      return {'temperatureValidator': true}
    }
    return null;
  }

  nameValidator (control: AbstractControl):{[key: string]: boolean} | null {

    //Regular Expression to match only alphabets(case insensitive) and space.
    let regexpName = new RegExp('^[a-zA-Z ]+$');

    if( control.value !==null && !regexpName.test(control.value)){
      return {'nameValidator': true}
    }
    return null;
  }

}
