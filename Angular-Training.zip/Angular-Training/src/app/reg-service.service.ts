import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Visitor } from './visitor';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RegServiceService {

  url = "http://localhost:8080/visitors-tracker/api"

  constructor(private http:HttpClient) { }

  saveLog(visitor:Visitor):Observable<Visitor>{
    return this.http.post<Visitor>(this.url+'/saveVisitorDetails',visitor)
  }
}
