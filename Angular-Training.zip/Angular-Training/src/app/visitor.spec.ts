import { Visitor } from './visitor';

describe('Visitor', () => {
  it('should create an instance', () => {
    expect(new Visitor()).toBeTruthy();
  });
});
