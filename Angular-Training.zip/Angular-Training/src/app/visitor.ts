export class Visitor {
    visitor_id: Number;
    name: String;
    address: String;
    phone: String;
    temperature: Number;
    organization_id: Number;
}
